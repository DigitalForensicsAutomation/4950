================================================================================
  Auto 49/50  -  Software Bundle
================================================================================

This folder contains the Auto 49/50 program and beginner guides.

CONTENTS
--------
  Auto4950\     The program files (do not separate these files)
  Guides\       Installation and user guides (Word and PDF)
  README.txt    This file


QUICK START (first time on a PC)
--------------------------------
  1. Copy the whole "Auto4950" folder to a permanent place, for example:
        C:\Tools\Auto4950

  2. Open the Guides folder and read:
        Auto4950_Install_Guide_Novice.pdf
     (or the .docx version if you prefer Word)

  3. Follow that guide. In short:
        - Map a network drive if your destination is on the network
          (see How_To_Map_Network_Drive_Windows10.pdf)
        - Double-click Fix-Permissions.bat (once)
        - Double-click Setup.bat and save your destination path
        - Double-click Start-Auto4950.bat to run the program


DAY-TO-DAY USE
--------------
  Open:  Auto4950_User_Guide_Novice.pdf

  Remember:
  - Pass number is required
  - Description, CMS case and OP name are optional
  - Description appears in the file name only
  - All files are saved under the Pass number subfolder


REQUIREMENTS
------------
  - Windows 10 or Windows 11
  - 7-Zip (https://www.7-zip.org) if not already installed


SUPPORT
-------
  If a script will not run, run Fix-Permissions.bat again.
  If destination Test fails in Setup, check the network path or mapped drive.

================================================================================
