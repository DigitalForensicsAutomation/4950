<#
.SYNOPSIS
    Auto 49/50 - USB Transfer Tool - first-run setup wizard.

.DESCRIPTION
    Creates or edits config.json. Lets you set the network share, locate 7-Zip,
    choose hashing/compression options and test connectivity before saving.
    Run this once before first use (or any time to reconfigure).

.EXAMPLE
    powershell -ExecutionPolicy Bypass -File .\Setup.ps1
#>

[CmdletBinding()]
param()

$ErrorActionPreference = 'Stop'
$scriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
Import-Module (Join-Path $scriptRoot 'Modules\Auto4950.Core.psm1') -Force
Add-Type -AssemblyName PresentationFramework, System.Windows.Forms

# ----------------------------------------------------------------------------
# Execution policy
# ----------------------------------------------------------------------------
# Auto 49/50 ships as unsigned .ps1 scripts. Windows' default execution policy
# ('Restricted' on client editions) blocks them, so users otherwise have to
# launch every time with '-ExecutionPolicy Bypass'. This offers to set a
# per-user 'RemoteSigned' policy once (no administrator rights required), after
# which the scripts can be launched by right-click -> "Run with PowerShell".
function Set-A4950ExecutionPolicy {
    $ok = @('RemoteSigned', 'Unrestricted', 'Bypass')
    try { $effective = Get-ExecutionPolicy } catch { return }
    if ($effective -in $ok) { return }   # already permissive enough

    # If Group Policy is forcing the policy, CurrentUser cannot override it.
    $mp = Get-ExecutionPolicy -Scope MachinePolicy
    $up = Get-ExecutionPolicy -Scope UserPolicy
    if ($mp -ne 'Undefined' -or $up -ne 'Undefined') {
        [System.Windows.MessageBox]::Show(
            "PowerShell's execution policy is '$effective', enforced by Group Policy " +
            "(Machine='$mp', User='$up').`n`nA local override isn't possible. Either ask your " +
            "administrator to allow 'RemoteSigned', or always launch the tool with:`n`n" +
            "    powershell -ExecutionPolicy Bypass -File .\Start-Auto4950.ps1",
            'Execution Policy (managed by Group Policy)', 'OK', 'Warning') | Out-Null
        return
    }

    $ans = [System.Windows.MessageBox]::Show(
        "PowerShell's execution policy is '$effective', which can block Auto 49/50 from running.`n`n" +
        "Set it to 'RemoteSigned' for your user account now?`n`n" +
        "- No administrator rights are required.`n" +
        "- It only affects your account.`n" +
        "- It lets locally-created scripts (this tool) run, while still requiring downloaded scripts to be signed.",
        'Execution Policy', 'YesNo', 'Question')
    if ($ans -ne 'Yes') { return }

    try {
        Set-ExecutionPolicy -Scope CurrentUser -ExecutionPolicy RemoteSigned -Force -ErrorAction Stop
        [System.Windows.MessageBox]::Show(
            "Done. Your account's execution policy is now 'RemoteSigned'.`n`n" +
            "You can now launch the tool by right-clicking Start-Auto4950.ps1 and choosing " +
            "'Run with PowerShell'.",
            'Execution Policy', 'OK', 'Information') | Out-Null
    } catch {
        [System.Windows.MessageBox]::Show(
            "Couldn't change the policy automatically:`n$($_.Exception.Message)`n`n" +
            "Run this once in a PowerShell window, then re-open Setup:`n`n" +
            "    Set-ExecutionPolicy -Scope CurrentUser RemoteSigned",
            'Execution Policy', 'OK', 'Error') | Out-Null
    }
}
Set-A4950ExecutionPolicy

$config     = Import-A4950Config
$configPath = Get-ConfigPath

[xml]$xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Auto 49/50 - Setup Wizard" Height="860" Width="640"
        WindowStartupLocation="CenterScreen" Background="#FF2A2A33" FontFamily="Segoe UI">
  <ScrollViewer VerticalScrollBarVisibility="Auto">
  <StackPanel Margin="18">
    <TextBlock FontSize="20" FontWeight="Bold">
      <Run Text="Auto " Foreground="#FFECECEC"/><Run Text="49/50" Foreground="#FF4FC3F7"/><Run Text="  -  Setup Wizard" Foreground="#FFECECEC"/>
    </TextBlock>
    <TextBlock Text="Configure destinations and defaults, then Save." Foreground="#FF9AA0A6" Margin="0,0,0,12"/>

    <TextBlock Text="1. Network share (UNC destination)" Foreground="#FFECECEC" FontWeight="SemiBold"/>
    <DockPanel Margin="0,2,0,4">
      <Button x:Name="BtnTestNet" Content="Test" DockPanel.Dock="Right" Padding="12,4" Margin="6,0,0,0" Foreground="#FF202020"/>
      <TextBox x:Name="Net" Padding="5" Background="#FF20202A" Foreground="#FFECECEC"/>
    </DockPanel>
    <TextBlock x:Name="NetStatus" Foreground="#FF9AA0A6" FontSize="11" Margin="0,0,0,10"/>

    <TextBlock Text="2. 7-Zip location" Foreground="#FFECECEC" FontWeight="SemiBold"/>
    <DockPanel Margin="0,2,0,4">
      <Button x:Name="BtnDetect" Content="Auto-detect" DockPanel.Dock="Right" Padding="12,4" Margin="6,0,0,0" Foreground="#FF202020"/>
      <TextBox x:Name="Sz" Padding="5" Background="#FF20202A" Foreground="#FFECECEC"/>
    </DockPanel>
    <TextBlock x:Name="SzStatus" Foreground="#FF9AA0A6" FontSize="11" Margin="0,0,0,10"/>

    <TextBlock Text="3. Staging folder (local, temporary)" Foreground="#FFECECEC" FontWeight="SemiBold"/>
    <TextBox x:Name="Stage" Padding="5" Margin="0,2,0,10" Background="#FF20202A" Foreground="#FFECECEC"/>

    <Grid>
      <Grid.ColumnDefinitions><ColumnDefinition/><ColumnDefinition/></Grid.ColumnDefinitions>
      <StackPanel Grid.Column="0" Margin="0,0,8,0">
        <TextBlock Text="4. Case prefix" Foreground="#FFECECEC" FontWeight="SemiBold"/>
        <TextBox x:Name="Prefix" Padding="5" Margin="0,2,0,10" Background="#FF20202A" Foreground="#FFECECEC"/>
        <TextBlock Text="All selected folders/files are always combined into ONE 7z archive." Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,0,0,10"/>
        <TextBlock Text="Split into volumes of (MB, 0 = single file)" Foreground="#FFECECEC" FontWeight="SemiBold"/>
        <TextBox x:Name="Volume" Padding="5" Margin="0,2,0,10" Background="#FF20202A" Foreground="#FFECECEC"/>
      </StackPanel>
      <StackPanel Grid.Column="1" Margin="8,0,0,0">
        <TextBlock Text="Compression level" Foreground="#FFECECEC" FontWeight="SemiBold"/>
        <Slider x:Name="Level" Minimum="0" Maximum="9" TickFrequency="1" IsSnapToTickEnabled="True" Margin="0,6,0,2"/>
        <TextBlock x:Name="LevelLbl" Foreground="#FF9AA0A6" Margin="0,0,0,10"/>
        <CheckBox x:Name="Sha" Content="Hash SHA-256" Foreground="#FFECECEC" Margin="0,2"/>
        <CheckBox x:Name="Md5" Content="Hash MD5" Foreground="#FFECECEC" Margin="0,2"/>
      </StackPanel>
    </Grid>

    <CheckBox x:Name="Embed"  Content="Embed hash manifest inside each archive" Foreground="#FFECECEC" Margin="0,6,0,2"/>
    <CheckBox x:Name="Auto"   Content="Prompt automatically when a USB drive is connected" Foreground="#FFECECEC" Margin="0,2"/>
    <CheckBox x:Name="All"    Content="Select all folders/files by default" Foreground="#FFECECEC" Margin="0,2"/>

    <Separator Margin="0,16,0,10"/>
    <TextBlock Text="5. Kiosk Mode (optional)" Foreground="#FFECECEC" FontWeight="SemiBold"/>
    <TextBlock Text="A simplified, full-screen, one-button front end for unattended intake stations - it asks for a Pass number (required), optional CMS case, and an external source drive, then transfers the whole drive using the settings above. Files are stored under a destination subfolder named after the Pass number. Save your configuration first." Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,2,0,10"/>
    <CheckBox x:Name="KioskAutoStart" Content="Also launch automatically when Windows starts (recommended for kiosk PCs)" Foreground="#FFECECEC" Margin="0,0,0,8"/>
    <StackPanel Orientation="Horizontal">
      <Button x:Name="BtnKiosk" Content="Create Kiosk Mode Shortcut" Padding="12,7" Margin="0,0,8,0" Background="#FF3A3A80" Foreground="#FFECECEC"/>
      <Button x:Name="BtnKioskRemoveAuto" Content="Remove Kiosk Auto-Start" Padding="12,7" Background="#FF5A3A3A" Foreground="#FFECECEC"/>
    </StackPanel>
    <TextBlock x:Name="KioskStatus" Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,6,0,0"/>

    <TextBlock Text="Blocked drives (cannot be selected in Kiosk Mode)" Foreground="#FFECECEC" FontWeight="SemiBold" Margin="0,14,0,2"/>
    <TextBlock Text="Stops a specific drive from ever being chosen as the Kiosk Mode source - e.g. a staff USB stick that should never be transferred. Matched by the drive's volume serial number, so it still applies if the drive letter changes." Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,0,0,8"/>
    <ListBox x:Name="BlockedList" Height="80" Background="#FF20202A" Foreground="#FFECECEC" Margin="0,0,0,6"/>
    <StackPanel Orientation="Horizontal">
      <Button x:Name="BtnBlockAdd" Content="Block a connected drive..." Padding="12,6" Margin="0,0,8,0" Background="#FF3A3A46" Foreground="#FFECECEC"/>
      <Button x:Name="BtnBlockRemove" Content="Unblock selected" Padding="12,6" Background="#FF3A3A46" Foreground="#FFECECEC"/>
    </StackPanel>
    <TextBlock x:Name="BlockStatus" Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,6,0,0"/>

    <TextBlock Text="Fast Transfer (optional)" Foreground="#FFECECEC" FontWeight="SemiBold" Margin="0,14,0,2"/>
    <TextBlock Text="Copies the drive's contents to a local drive first (Stage 1 - no hashing/compression, just a fast raw copy), then hashes, compresses and sends to the network destination in the background (Stage 2). Lets the USB/external drive be removed as soon as Stage 1 finishes, instead of staying connected for the whole job." Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,0,0,8"/>
    <CheckBox x:Name="FastTransferEnabled" Content="Enable Fast Transfer" Foreground="#FFECECEC" Margin="0,0,0,8"/>
    <TextBlock Text="Local drive for the Stage 1 copy" Foreground="#FF9AA0A6" FontSize="11"/>
    <DockPanel Margin="0,2,0,4">
      <Button x:Name="BtnFastDriveRefresh" Content="Refresh" DockPanel.Dock="Right" Padding="12,4" Margin="6,0,0,0" Foreground="#FF202020"/>
      <ComboBox x:Name="FastDrive" Padding="6" Background="#FF20202A" Foreground="#FFECECEC"/>
    </DockPanel>
    <TextBlock x:Name="FastTransferStatus" Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,4,0,10"/>

    <TextBlock Text="Notification sounds (Kiosk Mode and the main app)" Foreground="#FFECECEC" FontWeight="SemiBold" Margin="0,14,0,2"/>
    <TextBlock Text="Optional .wav files played on the events below - leave blank for the default Windows sound. Used by Kiosk Mode and the main app's Options panel alike." Foreground="#FF9AA0A6" FontSize="11" TextWrapping="Wrap" Margin="0,0,0,8"/>
    <TextBlock Text="Transfer started" Foreground="#FF9AA0A6" FontSize="11"/>
    <DockPanel Margin="0,2,0,8">
      <Button x:Name="BtnSoundStart" Content="Browse..." DockPanel.Dock="Right" Padding="12,4" Margin="6,0,0,0" Foreground="#FF202020"/>
      <TextBox x:Name="SoundStart" Padding="5" Background="#FF20202A" Foreground="#FFECECEC"/>
    </DockPanel>
    <TextBlock Text="Transfer completed" Foreground="#FF9AA0A6" FontSize="11"/>
    <DockPanel Margin="0,2,0,8">
      <Button x:Name="BtnSoundFinish" Content="Browse..." DockPanel.Dock="Right" Padding="12,4" Margin="6,0,0,0" Foreground="#FF202020"/>
      <TextBox x:Name="SoundFinish" Padding="5" Background="#FF20202A" Foreground="#FFECECEC"/>
    </DockPanel>
    <TextBlock Text="Transfer error" Foreground="#FF9AA0A6" FontSize="11"/>
    <DockPanel Margin="0,2,0,10">
      <Button x:Name="BtnSoundError" Content="Browse..." DockPanel.Dock="Right" Padding="12,4" Margin="6,0,0,0" Foreground="#FF202020"/>
      <TextBox x:Name="SoundError" Padding="5" Background="#FF20202A" Foreground="#FFECECEC"/>
    </DockPanel>

    <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,16,0,0">
      <Button x:Name="Save"   Content="Save configuration" Padding="16,7" Margin="4" Background="#FF2E7D32" Foreground="#FFECECEC"/>
      <Button x:Name="Cancel" Content="Close" Padding="16,7" Margin="4" Background="#FF3A3A46" Foreground="#FFECECEC"/>
    </StackPanel>
    <TextBlock x:Name="SaveStatus" Foreground="#FF66BB6A" Margin="0,8,0,0"/>
  </StackPanel>
  </ScrollViewer>
</Window>
"@

$w = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $xaml))
$g = { param($n) $w.FindName($n) }

(& $g 'Net').Text    = $config.NetworkShare
(& $g 'Sz').Text     = $config.SevenZipPath
(& $g 'Stage').Text  = $config.StagingFolder
(& $g 'Prefix').Text = $config.CasePrefix
(& $g 'Level').Value  = [double]$config.CompressionLevel
(& $g 'LevelLbl').Text = "Level $($config.CompressionLevel) (0=store, 9=ultra)"
(& $g 'Level').Add_ValueChanged({ (& $g 'LevelLbl').Text = "Level $([int](& $g 'Level').Value) (0=store, 9=ultra)" })
(& $g 'Sha').IsChecked    = ($config.HashAlgorithms -contains 'SHA256')
(& $g 'Md5').IsChecked    = ($config.HashAlgorithms -contains 'MD5')
(& $g 'Embed').IsChecked  = [bool]$config.EmbedManifest
(& $g 'Auto').IsChecked   = [bool]$config.AutoPromptOnInsert
(& $g 'All').IsChecked    = [bool]$config.DefaultSelectAll
(& $g 'Volume').Text = [string]([int]$config.VolumeSizeMB)
(& $g 'SoundStart').Text  = $config.SoundStartPath
(& $g 'SoundFinish').Text = $config.SoundFinishPath
(& $g 'SoundError').Text  = $config.SoundErrorPath

(& $g 'FastTransferEnabled').IsChecked = [bool]$config.KioskFastTransferEnabled
$script:FastTransferSubfolder = 'Auto4950FastTransfer'
function Update-FastDriveChoices {
    $currentDeviceId = if ($config.KioskFastTransferPath) { ($config.KioskFastTransferPath -split '\\')[0] } else { $null }
    (& $g 'FastDrive').Items.Clear()
    $drives = @(Get-A4950LocalFixedDrives)
    foreach ($d in $drives) {
        $freeGb = [math]::Round($d.FreeSpace / 1GB, 1)
        $label = "{0}  {1}  ({2} GB free)" -f $d.DeviceID, ($(if ($d.VolumeName) { $d.VolumeName } else { '(no label)' })), $freeGb
        [void](& $g 'FastDrive').Items.Add($label)
    }
    if ((& $g 'FastDrive').Items.Count -eq 0) {
        (& $g 'FastTransferStatus').Text = 'No local fixed drive detected to use for Fast Transfer.'
        (& $g 'FastTransferStatus').Foreground = '#FFFFCA28'
        return
    }
    (& $g 'FastTransferStatus').Text = ''
    $preselect = 0
    if ($currentDeviceId) {
        for ($i = 0; $i -lt $drives.Count; $i++) { if ($drives[$i].DeviceID -eq $currentDeviceId) { $preselect = $i; break } }
    }
    (& $g 'FastDrive').SelectedIndex = $preselect
}
Update-FastDriveChoices
(& $g 'BtnFastDriveRefresh').Add_Click({ Update-FastDriveChoices })

$script:BlockedDrives = New-Object System.Collections.Generic.List[object]
foreach ($b in @($config.KioskBlockedDrives)) {
    if ($b -and $b.Serial) { $script:BlockedDrives.Add([pscustomobject]@{ Serial = $b.Serial; Label = $b.Label }) }
}
function Update-BlockedList {
    (& $g 'BlockedList').Items.Clear()
    foreach ($b in $script:BlockedDrives) { [void](& $g 'BlockedList').Items.Add("$($b.Label)  [$($b.Serial)]") }
}
Update-BlockedList

(& $g 'BtnTestNet').Add_Click({
    $path = (& $g 'Net').Text.Trim()
    if (Test-Path -LiteralPath $path) {
        (& $g 'NetStatus').Text = "Reachable and writable check..."
        try {
            $probe = Join-Path $path (".bswrite_{0}.tmp" -f ([guid]::NewGuid().ToString('N')))
            'probe' | Set-Content -LiteralPath $probe -ErrorAction Stop
            Remove-Item -LiteralPath $probe -Force -ErrorAction SilentlyContinue
            (& $g 'NetStatus').Text = "OK - share is reachable and writable."
            (& $g 'NetStatus').Foreground = '#FF66BB6A'
        } catch {
            (& $g 'NetStatus').Text = "Reachable but NOT writable: $($_.Exception.Message)"
            (& $g 'NetStatus').Foreground = '#FFFFCA28'
        }
    } else {
        (& $g 'NetStatus').Text = "Not reachable: $path"
        (& $g 'NetStatus').Foreground = '#FFEF5350'
    }
})

(& $g 'BtnDetect').Add_Click({
    $found = Resolve-SevenZip
    if ($found) {
        (& $g 'Sz').Text = $found
        (& $g 'SzStatus').Text = "Found: $found"
        (& $g 'SzStatus').Foreground = '#FF66BB6A'
        return
    }
    # Not auto-detected: let the operator browse to 7z.exe manually.
    (& $g 'SzStatus').Text = '7-Zip not auto-detected. Browse to 7z.exe, or install from https://www.7-zip.org'
    (& $g 'SzStatus').Foreground = '#FFFFCA28'
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title  = 'Locate 7z.exe (7-Zip command-line executable)'
    $dlg.Filter = '7-Zip executable (7z.exe;7za.exe)|7z.exe;7za.exe|Executables (*.exe)|*.exe'
    foreach ($seed in @("$env:ProgramW6432\7-Zip", "$env:ProgramFiles\7-Zip", "${env:ProgramFiles(x86)}\7-Zip")) {
        if ($seed -and (Test-Path -LiteralPath $seed)) { $dlg.InitialDirectory = $seed; break }
    }
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) {
        (& $g 'Sz').Text = $dlg.FileName
        (& $g 'SzStatus').Text = "Selected: $($dlg.FileName)"
        (& $g 'SzStatus').Foreground = '#FF66BB6A'
    }
})

function New-A4950Shortcut {
    <#
    .SYNOPSIS Create a .lnk shortcut to the Kiosk Mode launcher.
    #>
    param([Parameter(Mandatory)][string]$Path, [Parameter(Mandatory)][string]$TargetBat, [Parameter(Mandatory)][string]$WorkDir)
    $wsh = New-Object -ComObject WScript.Shell
    $sc = $wsh.CreateShortcut($Path)
    $sc.TargetPath = $TargetBat
    $sc.WorkingDirectory = $WorkDir
    $sc.Description = 'Auto 49/50 - Kiosk Mode'
    $sc.Save()
}

function Select-WavFile {
    param([string]$Title = 'Select a .wav sound file')
    $dlg = New-Object System.Windows.Forms.OpenFileDialog
    $dlg.Title  = $Title
    $dlg.Filter = 'WAV audio (*.wav)|*.wav|All files (*.*)|*.*'
    if ($dlg.ShowDialog() -eq [System.Windows.Forms.DialogResult]::OK) { return $dlg.FileName }
    return $null
}
(& $g 'BtnSoundStart').Add_Click({ $p = Select-WavFile -Title 'Select transfer-started sound (.wav)'; if ($p) { (& $g 'SoundStart').Text = $p } })
(& $g 'BtnSoundFinish').Add_Click({ $p = Select-WavFile -Title 'Select transfer-completed sound (.wav)'; if ($p) { (& $g 'SoundFinish').Text = $p } })
(& $g 'BtnSoundError').Add_Click({ $p = Select-WavFile -Title 'Select transfer-error sound (.wav)'; if ($p) { (& $g 'SoundError').Text = $p } })

function Show-DrivePickerDialog {
    <#
    .SYNOPSIS Small modal to pick one connected drive from a list, for the "block a drive" flow.
    #>
    param([Parameter(Mandatory)][array]$Drives)
    [xml]$pxaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="Block a Drive" Height="220" Width="440" WindowStartupLocation="CenterScreen"
        ResizeMode="NoResize" Background="#FF2A2A33" FontFamily="Segoe UI">
  <StackPanel Margin="18">
    <TextBlock Text="Select the connected drive to block from Kiosk Mode:" Foreground="#FFECECEC" TextWrapping="Wrap" Margin="0,0,0,10"/>
    <ComboBox x:Name="CmbPick" Padding="6" FontSize="14"/>
    <StackPanel Orientation="Horizontal" HorizontalAlignment="Right" Margin="0,18,0,0">
      <Button x:Name="BtnPCancel" Content="Cancel" Padding="14,6" Margin="4" Background="#FF3A3A46" Foreground="White" BorderThickness="0"/>
      <Button x:Name="BtnPOk" Content="Block" Padding="14,6" Margin="4" Background="#FF8E2A2A" Foreground="White" BorderThickness="0" FontWeight="Bold"/>
    </StackPanel>
  </StackPanel>
</Window>
"@
    $pw = [Windows.Markup.XamlReader]::Load((New-Object System.Xml.XmlNodeReader $pxaml))
    $pg = { param($n) $pw.FindName($n) }
    $pw.Owner = $w
    foreach ($d in $Drives) {
        $label = "{0}  {1}" -f $d.DeviceID, ($(if ($d.VolumeName) { $d.VolumeName } else { '(no label)' }))
        [void](& $pg 'CmbPick').Items.Add($label)
    }
    (& $pg 'CmbPick').SelectedIndex = 0
    $script:DrivePickResult = $null
    (& $pg 'BtnPCancel').Add_Click({ $pw.DialogResult = $false; $pw.Close() })
    (& $pg 'BtnPOk').Add_Click({
        $idx = (& $pg 'CmbPick').SelectedIndex
        if ($idx -ge 0) { $script:DrivePickResult = $Drives[$idx] }
        $pw.DialogResult = $true
        $pw.Close()
    })
    [void]$pw.ShowDialog()
    return $script:DrivePickResult
}

(& $g 'BtnBlockAdd').Add_Click({
    $drives = @(Get-A4950RemovableDrives)
    if (-not $drives.Count) {
        (& $g 'BlockStatus').Text = 'No external/removable drive is currently connected. Connect the drive you want to block, then try again.'
        (& $g 'BlockStatus').Foreground = '#FFFFCA28'
        return
    }
    $picked = Show-DrivePickerDialog -Drives $drives
    if (-not $picked) { return }
    if (-not $picked.VolumeSerialNumber) {
        (& $g 'BlockStatus').Text = 'That drive has no volume serial number to match against, so it cannot be blocked.'
        (& $g 'BlockStatus').Foreground = '#FFEF5350'
        return
    }
    if ($script:BlockedDrives.Serial -contains $picked.VolumeSerialNumber) {
        (& $g 'BlockStatus').Text = 'That drive is already blocked.'
        (& $g 'BlockStatus').Foreground = '#FF9AA0A6'
        return
    }
    $label = "{0}  {1}" -f $picked.DeviceID, ($(if ($picked.VolumeName) { $picked.VolumeName } else { '(no label)' }))
    $script:BlockedDrives.Add([pscustomobject]@{ Serial = $picked.VolumeSerialNumber; Label = $label })
    Update-BlockedList
    (& $g 'BlockStatus').Text = "Blocked $label. Click 'Save configuration' below to keep it."
    (& $g 'BlockStatus').Foreground = '#FF66BB6A'
})

(& $g 'BtnBlockRemove').Add_Click({
    $idx = (& $g 'BlockedList').SelectedIndex
    if ($idx -lt 0) {
        (& $g 'BlockStatus').Text = 'Select a blocked drive in the list first.'
        (& $g 'BlockStatus').Foreground = '#FFFFCA28'
        return
    }
    $script:BlockedDrives.RemoveAt($idx)
    Update-BlockedList
    (& $g 'BlockStatus').Text = "Unblocked. Click 'Save configuration' below to keep it."
    (& $g 'BlockStatus').Foreground = '#FF66BB6A'
})

(& $g 'BtnKiosk').Add_Click({
    $kioskBat = Join-Path $scriptRoot 'Start-Auto4950-Kiosk.bat'
    if (-not (Test-Path -LiteralPath $kioskBat)) {
        (& $g 'KioskStatus').Text = 'Could not find Start-Auto4950-Kiosk.bat next to Setup.ps1.'
        (& $g 'KioskStatus').Foreground = '#FFEF5350'
        return
    }
    try {
        $desktopPath = Join-Path ([Environment]::GetFolderPath('Desktop')) 'Auto 49-50 Kiosk.lnk'
        New-A4950Shortcut -Path $desktopPath -TargetBat $kioskBat -WorkDir $scriptRoot
        $msg = "Desktop shortcut created: $desktopPath"

        if ((& $g 'KioskAutoStart').IsChecked) {
            $startupPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'Auto 49-50 Kiosk.lnk'
            New-A4950Shortcut -Path $startupPath -TargetBat $kioskBat -WorkDir $scriptRoot
            $msg += "`nAlso set to launch automatically at sign-in (Startup folder, this account only)."
        }
        (& $g 'KioskStatus').Text = $msg
        (& $g 'KioskStatus').Foreground = '#FF66BB6A'
    } catch {
        (& $g 'KioskStatus').Text = "Could not create the shortcut: $($_.Exception.Message)"
        (& $g 'KioskStatus').Foreground = '#FFEF5350'
    }
})

(& $g 'BtnKioskRemoveAuto').Add_Click({
    try {
        $startupPath = Join-Path ([Environment]::GetFolderPath('Startup')) 'Auto 49-50 Kiosk.lnk'
        if (Test-Path -LiteralPath $startupPath) {
            Remove-Item -LiteralPath $startupPath -Force
            (& $g 'KioskStatus').Text = "Kiosk auto-start removed from Startup folder.`n($startupPath)"
            (& $g 'KioskStatus').Foreground = '#FF66BB6A'
            (& $g 'KioskAutoStart').IsChecked = $false
        } else {
            (& $g 'KioskStatus').Text = 'No Kiosk auto-start shortcut was found in the Startup folder for this account.'
            (& $g 'KioskStatus').Foreground = '#FFFFCA28'
        }
    } catch {
        (& $g 'KioskStatus').Text = "Could not remove auto-start: $($_.Exception.Message)"
        (& $g 'KioskStatus').Foreground = '#FFEF5350'
    }
})

(& $g 'Cancel').Add_Click({ $w.Close() })
(& $g 'Save').Add_Click({
    $config.NetworkShare        = (& $g 'Net').Text.Trim()
    $config.SevenZipPath        = (& $g 'Sz').Text.Trim()
    $config.StagingFolder       = (& $g 'Stage').Text.Trim()
    $config.CasePrefix          = (& $g 'Prefix').Text.Trim()
    $config.CompressionLevel    = [int](& $g 'Level').Value
    $vol = 0; [void][int]::TryParse((& $g 'Volume').Text.Trim(), [ref]$vol); if ($vol -lt 0) { $vol = 0 }
    $config.VolumeSizeMB        = $vol
    $algs = @(); if ((& $g 'Sha').IsChecked) { $algs += 'SHA256' }; if ((& $g 'Md5').IsChecked) { $algs += 'MD5' }
    if ($algs.Count -eq 0) { $algs = @('SHA256') }
    $config.HashAlgorithms      = $algs
    $config.EmbedManifest       = [bool](& $g 'Embed').IsChecked
    $config.AutoPromptOnInsert  = [bool](& $g 'Auto').IsChecked
    $config.DefaultSelectAll    = [bool](& $g 'All').IsChecked
    $config.SoundStartPath      = (& $g 'SoundStart').Text.Trim()
    $config.SoundFinishPath     = (& $g 'SoundFinish').Text.Trim()
    $config.SoundErrorPath      = (& $g 'SoundError').Text.Trim()
    $config.KioskBlockedDrives  = @($script:BlockedDrives | ForEach-Object { @{ Serial = $_.Serial; Label = $_.Label } })

    $config.KioskFastTransferEnabled = [bool](& $g 'FastTransferEnabled').IsChecked
    $fastSel = (& $g 'FastDrive').SelectedItem
    if ($fastSel) {
        $selectedDeviceId = $fastSel.ToString().Split(' ')[0]   # e.g. "D:"
        $config.KioskFastTransferPath = Join-Path $selectedDeviceId $script:FastTransferSubfolder
    } elseif ($config.KioskFastTransferEnabled) {
        # Enabled but nothing to copy to - don't silently save a broken setup.
        (& $g 'FastTransferStatus').Text = 'Fast Transfer needs a local drive selected above - it has been left disabled.'
        (& $g 'FastTransferStatus').Foreground = '#FFEF5350'
        $config.KioskFastTransferEnabled = $false
    }
    Save-A4950Config -Config $config -Path $configPath | Out-Null

    $issues = Test-A4950Config -Config $config
    if ($issues.Count) {
        (& $g 'SaveStatus').Text = "Saved to $configPath (with warnings: $($issues -join '; '))"
        (& $g 'SaveStatus').Foreground = '#FFFFCA28'
    } else {
        (& $g 'SaveStatus').Text = "Saved to $configPath. Configuration valid. You can close and run Start-Auto4950.ps1."
        (& $g 'SaveStatus').Foreground = '#FF66BB6A'
    }
})

[void]$w.ShowDialog()
